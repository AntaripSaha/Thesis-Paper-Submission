<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Article extends Model
{
    //                                                              //key words
    protected $fillable = ['user_id','title', 'field', 'introduction', 'keyword', 'image', 'image2', 'rating', 'category'];

    public function user() {
    	return $this->belongsTo('App\User');
    }

    public function likes() {
    	return $this->hasMany('App\Like');
    }

    public function comments() {
    	return $this->hasMany('App\Comment');
    }

    public function subcomments() {
        return $this->hasMany('App\Subcomment');
    }

    public function delete() {
        $this->likes()->delete();
        $this->comments()->delete();
        $this->subcomments()->delete();
        return parent::delete();
    }
}
