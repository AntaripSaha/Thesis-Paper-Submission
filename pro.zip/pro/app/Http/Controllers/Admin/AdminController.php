<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Excel;

class AdminController extends Controller
{
    //

       public function show() {
    	$userlist = User::all();
    	return view('admin.index', ['userlist'=>$userlist]);
    }


      function exportD(){



$userlist = User::all();


     $userlist = User::all();
     $customer_array[] = array( 'id', 'username', 'name', 'surname', 'affiliation', 'email');
     foreach($userlist as $user)
     {
        $customer_array[] = array(
        $user->id,
        $user->username,
       $user->name,
       $user->surname,
       $user->affiliation,
       $user->email,
      );
     }

//      Excel::create('Filename', function($excel) {

// })->export('xls');

// dd($customer_array);
     Excel::create('Journal User List', function($excel) use ($customer_array){
      $excel->setTitle('Journal User List');
      $excel->sheet('Journal User List', function($sheet) use ($customer_array){
       $sheet->fromArray($customer_array, null, 'A1', false, false);
      });
     })->download('csv');



       // return "test success";

  }




}
