<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Article;
use Excel;




class UserListController extends Controller
{
    //Documents page controller

    public function show() {
    	$userlist = Article::all();
    	return view('admin.userlist', ['userlist'=>$userlist]);
    }




    // public function destroy($id){

    //     $userlist = User::find($id);

    //     $userlist->destroy($id);

    //     return redirect(route('admin.userlist'));

    // }




    //     public function destroy($id)
    // {
    //     $userlist = User::find($id);
    //     $userlist->delete();
    //     return redirect('/admin.userlist');

    
    // }


    function exportData(){



$userlist = Article::all();


     $userlist = Article::all();
     $customer_array[] = array( 'user_id', 'title', 'field', 'introduction', 'keyword');
     foreach($userlist as $user)
     {
        $customer_array[] = array(
        $user->user_id,
        $user->title,
       $user->field,
       $user->introduction,
       $user->keyword,
      // $user->image,
      // $user->image2
      );
     }

//      Excel::create('Filename', function($excel) {

// })->export('xls');

// dd($customer_array);
     Excel::create('Journal Documentaion', function($excel) use ($customer_array){
      $excel->setTitle('Journal Documentaion');
      $excel->sheet('Journal Documentaion', function($sheet) use ($customer_array){
       $sheet->fromArray($customer_array, null, 'A1', false, false);
      });
     })->download('csv');



       // return "test success";


      
//return Excel::create('userlist', function($userlist) {})->export('xls');


     // return Excel::download(new DataExport, 'documents.xlsx');


  }





   

// 

}


// class DataExport implements FromCollection{
    
//     function collection()
//     {
        

//         return Article::all();
//     }
// }

