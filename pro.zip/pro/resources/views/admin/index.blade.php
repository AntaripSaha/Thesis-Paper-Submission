@extends('layouts.main')

@section('content')
<style type="text/css">
	
.design{
	padding-top: 15%;
}	
</style>


<div class="col-xs-8">
	<div class="panel panel-default">
		<div class="panel-body">
				<h3>User List</h3>


		</div>
		            <a href="{{ route('export1') }}" class="list-group-item">Download</a>

	</div>

	<div class="design">
								<table class="table">
								<tr>
									<th>ID</th>
									<th>USER NAME</th>
									<th>FIRST NAME</th>
									<th>LAST NAME</th>
									<th>EMAIL</th>
									<th>AFFILIATION</th>
									<th>ADMIN</th>
								</tr>
							@foreach($userlist as $user)
								<tr>
									<td>{{$user->id}}</td>
									<td>{{$user->username}}</td>
									<td>{{$user->name}}</td>
									<td>{{$user->surname}}</td>
									<td>{{$user->email}}</td>
									<td>{{$user->affiliation}}</td>
									<td>{{$user->admin}}</td>
									
								</tr>											
							@endforeach
							</table>

	</div>						



</div>
@endsection

@section('sidebar')
<div class="col-xs-4">
  <div class="row">
    <div class="panel-group">
      <div class="panel panel-default">
        <div class="panel-heading">
          <h3 class="panel-title">Admin panel</h3>
        </div>
        <div class="panel-body">
          <ul class="list-group">
            <a href="{{ route('adminIndex') }}" class="list-group-item">User List</a>
            <a href="{{ route('userList') }}" class="list-group-item">Document</a>

          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection