

@extends('layouts.main')

@section('content')

<style type="text/css">
	
.design{
	padding-top: 15%;
}	
.li{
    max-width:200px;
    word-wrap:break-word;
}

</style>

<!-- 	
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

 -->

	

<div class="col-xs-8">
  <div class="panel panel-default">
    <div class="panel-body">
      <h3>Documents</h3>
    </div>
                <a href="{{ route('export') }}" class="list-group-item">Download</a>

  </div>


<div class="design">
<table class="table">
  <tr>
      <th scope="col">ID</th>


<!--       <th scope="col">Id</th>
 -->

      <th scope="col">Category</th>
      <th scope="col">Title</th>
      <th scope="col">Field</th>
      <th scope="col">Abstract</th>
      <th scope="col">Key Word</th>
      <th scope="col">Pdf File</th>
      <th scope="col">Docx File</th>      
      <!--<th scope="col">DELETE</th>      -->

   </tr>
  @foreach($userlist as $user)
  <tr>



      <th scope="row">{{$user['user_id']}}</th>

<!--       <td>{{$user['id']}}</td>
 -->      
      <td>{{$user['category']}}</td>
      <td>{{$user['title']}}</td>
      <td>{{$user['field']}}</td>

      <!-- character limit for introduction or Abstract -->


<!--       <td>{{$user['introduction']}}</td>
 -->      
     <td>{{str_limit($user->introduction,100,'...')}}</td>


      <td>{{$user['keyword']}}</td>
      <td><a href="{{asset('uploads/employee/'.$user->image)}}">{{$user['image']}}</td> 
      <td><a href="{{asset('uploads/employee/'.$user->image2)}}">{{$user['image2']}}</td> 


      <!--<td><a href="/delete/{{$user->id}}" class="btn btn-danger">Delete</a></td> -->

      <!-- <td><a href={{"delete/".$user['id']}} class="btn btn-danger">Delete</a></td> -->

  </tr>                     
@endforeach
</table>
</div>




</div>
@endsection

@section('sidebar')
<div class="col-xs-4">
  <div class="row">
    <div class="panel-group">
      <div class="panel panel-default">
        <div class="panel-heading">
          <h3 class="panel-title">Admin panel</h3>
        </div>
        <div class="panel-body">
          <ul class="list-group">
            <a href="{{ route('adminIndex') }}" class="list-group-item">User List</a>
            <a href="{{ route('userList') }}" class="list-group-item">Document</a>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection