@extends('layouts.main')

@section('content')
<header>
	<style type="text/css">
		body{
	
		background-image: url('/ICPACE-21-web-banner-scaled-1-1.jpg');
		background-repeat: no-repeat;
		background-attachment: fixed;
        background-size: 100% 40%;


	}

	</style>
	
</header>






<div class="col-xs-12">
	<div class="panel panel-default">
		<div class="panel-body">
			<h2><b>Paper Submission</h2>
			<hr>
			<div class="panel panel-default">
				<div class="panel-body">
					<form method="POST" enctype="multipart/form-data" action="{{ route('articles.store') }}">
						{{ csrf_field() }}



 						
						<div class="form-group{{ $errors->has('category') ? ' has-error' : '' }}">

						  <label for="category"><h4><b>Choose a Category:</h4></label>

							<select name="category" id="">
							  <option value="Abstract Submission">Abstract Submission</option>
  							  <option value="Full Paper Submission">Full Paper Submission</option>
  							  <option value="Camera Ready Paper Submission">Camera Ready Paper Submission</option>
  							  							  
							</select>

							@if($errors->has('category'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('category') }}</strong>
                                </span>
                            @endif							

						</div>
						<hr>






						<div class="form-group{{ $errors->has('title') ? ' has-error' : '' }}">
							<label for="title"><h4><b>Paper Title *</h4></label>
							<input type="text" class="form-control" name="title" value="{{ old('title') }}" placeholder="Title">
							@if($errors->has('title'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('title') }}</strong>
                                </span>
                            @endif
						</div>

						<hr>






						<div class="form-group{{ $errors->has('field') ? ' has-error' : '' }}">

						  <label for="field"><h4><b>Choose a Field:</h4></label>

							<select name="field" id="">
							  <option value="Structure Engineering">Structure Engineering</option>
  							  <option value="Geotechnical Engineering">Geotechnical Engineering</option>
  							  <option value="Water Resource Engineering">Water Resource Engineering</option>
  							  <option value="Environmental Engineering">Environmental Engineering</option>
							  <option value="Transportation Engineering">Transportation Engineering</option>
  							  <option value="Architecture">Architecture</option>
  							  <option value="Planning">Planning</option>
  							  <option value="Building Construction">Building Construction</option>
  							  <option value="Others">Others</option>  							  
							</select>

							@if($errors->has('field'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('field') }}</strong>
                                </span>
                            @endif							

						</div>
						<hr>
						






						<div class="form-group{{ $errors->has('introduction') ? ' has-error' : '' }}">
							<label for="introduction"><h4><b>Abstract*</h4></label>
							<textarea class="form-control comment-box" name="introduction" id="" cols="30" rows="10" placeholder="Maximum 250 Words">{{ old('introduction') }}</textarea>
							@if($errors->has('introduction'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('introduction') }}</strong>
                                </span>
                            @endif
						</div>
						<hr>
 


						<div class="form-group{{ $errors->has('keyword') ? ' has-error' : '' }}">
							<label for="keyword"><h4><b>Key Words*</h4></label>
							<input type="text" class="form-control" name="keyword" value="{{ old('keyword') }}" placeholder="Maximum 5">

							@if($errors->has('keyword'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('keyword') }}</strong>
                                </span>
                            @endif
						</div>


						<div class="form-group{{ $errors->has('tags') ? ' has-error' : '' }} form-group mt-3">
						



							<hr>
							<!-------file upload section---->
							<label class="mr-2"><h4><b>Upload Pdf File:</h4></label> <!-------file upload section---->
							<input type="file" name="image" >
							<!-------file upload section---->
							<hr>




							@if($errors->has('tags'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('tags') }}</strong>
                                </span>
                            @endif
						</div>






						<div class="form-group{{ $errors->has('tags') ? ' has-error' : '' }} form-group mt-3">

							<hr>
							<!-------file upload section---->
							<label class="mr-2"><h4><b>Upload Docx File:</h4></label> <!-------file upload section---->
							<input type="file" name="image2" >
							<!-------file upload section---->
							<hr>

							@if($errors->has('tags'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('tags') }}</strong>
                                </span>
                            @endif
						</div>









						
<!-- 						<div class="form-group{{ $errors->has('article') ? ' has-error' : '' }}">
							<label for="article">Article *</label>
							<textarea class="form-control" name="article" id="" cols="30" rows="10" placeholder="Your article here">{{ old('article') }}</textarea>
							@if($errors->has('article'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('article') }}</strong>
                                </span>
                            @endif
						</div> -->


						<div class="form-group">
							<button class="btn btn-primary">Submit</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection