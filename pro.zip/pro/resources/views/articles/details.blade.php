<!DOCTYPE html>
<html>
<head>
	<title>Details</title>
</head>
<body>


						@foreach($article as $key=>$data)
						<div>
							 <a href="/">View File</a> 
			 				 <iframe src="{{url('storage/'.$data->file)}}"></iframe>

						</div>

						@endforeach


</body>
</html>