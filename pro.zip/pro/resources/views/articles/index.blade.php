<header>
	<style type="text/css">
		

body{
	
		background-image: url('/ICPACE-21-web-banner-scaled-1-1.jpg');
		background-repeat: no-repeat;
		background-size: 100% 40%;


	}

.resize{
		padding-top: 300px;

	}

.block {
  display: block;
  width: 100%;
  border: none;
  background-color: #98e3cb;
  padding: 14px 28px;
  font-size: 16px;
  cursor: pointer;
  text-align: center;

}


.block:hover {
  background-color:#54f0bc;
  color: black;
}

	</style>


	
</header>




@extends('layouts.main')

@section('content')

<div class="col-xs-8 resize">

	<div class="panel panel-default ">
		<div class="panel-body">




		<h3>
			<form action="{{ route('articles.create') }}">
				<button type="submit" class="block"><h4><b>Paper Submission page</b></h4></button>
				
			</form>
			
		</h3>




			<hr>


<!-- 			<div class="panel-group">
				@if(!empty($articles))
					@foreach($articles as $article)
						<div class="panel panel-default">
							<div class="panel-heading">
								<h3 class="panel-title pull-left"><b><a href="{{ route('articles.show', $article->id) }}">{{ $article->title }}</a></b></h3>								
								@if(!Auth::guest())
									@if(Auth::user()->admin)
									<div class="pull-right">
										<form method="POST" action="{{ route('articles.destroy', $article->id) }}">
											<a href="{{ route('articles.edit', $article->id) }}" class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
											{{ csrf_field() }}
											{{ method_field('DELETE') }}
											<button class="btn btn-danger btn-xs"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
										</form>
									</div>
									@else
										@foreach(Auth::user()->articles as $userArticle)
											@if($userArticle->id == $article->id)
											<div class="pull-right">
												<form method="POST" action="{{ route('articles.destroy', $article->id) }}">
													<a href="{{ route('articles.edit', $article->id) }}" class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
													{{ csrf_field() }}
													{{ method_field('DELETE') }}
													<button class="btn btn-danger btn-xs"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
												</form>
											</div>
											@endif
										@endforeach
									@endif
								@endif
								<div class="clearfix"></div>
							</div>
							<div class="panel-body">
								<p>{{ $article->introduction }}</p>
								<a href="{{ route('articles.show', $article->id) }}" class="btn btn-link pull-right">Read more</a>
							</div>
						</div>
					@endforeach
				@endif
			</div>



 -->


			
		</div>
	</div>
</div>
@endsection


 @section('sidebar')
@include('layouts.includes.sidebar')
@endsection