@extends('layouts.main')



@section('content')


<header>
    <style type="text/css">
        body{
    
        background-image: url('/ICPACE-21-web-banner-scaled-1-1.jpg');
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: 100% 40%;


    }
     .resize{
        padding-top: 300px;

    }

    </style>
    
</header>


<div class="col-xs-8 resize">
    <div class="panel panel-default">
        <div class="panel-body">
            <h3>Sign up</h3>
            <hr>
            <div class="panel panel-default">
                <div class="panel-body">
                    <form role="form" method="POST" action="{{ route('register') }}">
                        {{ csrf_field() }}



   





                        <div class="row">
                            <div class="col-xs-6">
                                <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                                    <label for="name">First Name</label>
                                    <input type="text" class="form-control" name="name" value="{{ old('name') }}" placeholder="First Name" required>
                                    @if($errors->has('name'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('name') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-xs-6">
                                <div class="form-group{{ $errors->has('surname') ? ' has-error' : '' }}">
                                    <label for="surname">Last Name</label>
                                    <input type="text" class="form-control" name="surname" value="{{ old('surname') }}" placeholder="Last Name" required>
                                    @if($errors->has('surname'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('surname') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                        </div>





                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group{{ $errors->has('affiliation') ? ' has-error' : '' }}">
                                    <label for="affiliation">Affiliation</label>
                                    <input type="text" class="form-control" name="affiliation" value="{{ old('affiliation') }}" placeholder="Affiliation">
                                    @if($errors->has('affiliation'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('affiliation') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                        </div>
















                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                    <label for="email">E-mail</label>
                                    <input type="email" class="form-control" name="email" value="{{ old('email') }}" placeholder="Remember this E-mail for further login" required>
                                    @if($errors->has('email'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('email') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                        </div>






                        

                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group{{ $errors->has('username') ? ' has-error' : '' }}">
                                    <label for="username">Username</label>
                                    <input type="text" class="form-control" name="username" value="{{ old('username') }}" placeholder="Username" required autofocus>
                                    @if($errors->has('username'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('username') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                        </div>                     




                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                                    <label for="password">Password</label>
                                    <input type="password" class="form-control" name="password" placeholder="Remember this Password for further login" required>
                                    @if($errors->has('password'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('password') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                        </div>



                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group">
                                    <button class="btn btn-primary">Sign up</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('sidebar')
@include('layouts.includes.sidebar')
@endsection