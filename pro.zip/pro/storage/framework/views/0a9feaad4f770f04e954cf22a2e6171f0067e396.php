<?php $__env->startSection('content'); ?>
<div class="col-xs-8">
	<div class="panel panel-default">
		<div class="panel-body">
			<h3>Guest book</h3>
			<hr>
			<div class="panel panel-default">
				<div class="panel-body">
					<form action="<?php echo e(route('feedback.store')); ?>" method="POST">
						<?php echo e(csrf_field()); ?>

						<div class="row">
							<div class="col-xs-12">
								<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
									<label for="name">Name *</label>
									<input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" placeholder="Name">
									<?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
									<label for="email">E-mail</label>
									<input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="E-mail">
									<?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								<div class="form-group<?php echo e($errors->has('message') ? ' has-error' : ''); ?>">
									<label for="message">Your text</label>
									<textarea name="message" class="form-control comment-box" id="" cols="30" rows="10" placeholder="Your text here..."><?php echo e(old('message')); ?></textarea>
									<?php if($errors->has('message')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('message')); ?></strong>
                                        </span>
                                    <?php endif; ?>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-12">
								<div class="form-group">
									<button class="btn btn-success">Add</button>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
			<div class="panel-group">
				<?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="panel panel-default">
					<div class="panel-heading">
						<b><?php echo e($feedback->name); ?></b>
						<?php if(!Auth::guest() && Auth::user()->admin): ?>
						<div class="pull-right">
							<form method="POST" action="<?php echo e(route('feedback.destroy', $feedback->id)); ?>">
								<?php echo e(csrf_field()); ?>

								<?php echo e(method_field('DELETE')); ?>

								<button class="btn btn-danger btn-xs"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
							</form>
						</div>
						<?php endif; ?>
					</div>
					<div class="panel-body">
						<?php echo e($feedback->message); ?><div class="pull-right"><a href="mailto:<?php echo e($feedback->email); ?>" class="btn btn-link">E-mail</a></div>
					</div>
					<div class="clearfix"></div>
				</div>
				<?php if(!$loop->last): ?>
				<br>
				<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>			
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('layouts.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>