<?php $__env->startSection('content'); ?>
<style type="text/css">
	
.design{
	padding-top: 15%;
}	
</style>


<div class="col-xs-8">
	<div class="panel panel-default">
		<div class="panel-body">
				<h3>User List</h3>


		</div>
	</div>

	<div class="design">
								<table class="table">
								<tr>
									<th>ID</th>
									<th>USER NAME</th>
									<th>FIRST NAME</th>
									<th>LAST NAME</th>
									<th>EMAIL</th>
									<th>AFFILIATION</th>
									<th>ADMIN</th>
								</tr>
							<?php $__currentLoopData = $userlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($user->id); ?></td>
									<td><?php echo e($user->username); ?></td>
									<td><?php echo e($user->name); ?></td>
									<td><?php echo e($user->surname); ?></td>
									<td><?php echo e($user->email); ?></td>
									<td><?php echo e($user->birthdate); ?></td>
									<td><?php echo e($user->admin); ?></td>
									
								</tr>											
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</table>

	</div>						



</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<div class="col-xs-4">
  <div class="row">
    <div class="panel-group">
      <div class="panel panel-default">
        <div class="panel-heading">
          <h3 class="panel-title">Admin panel</h3>
        </div>
        <div class="panel-body">
          <ul class="list-group">
            <a href="<?php echo e(route('adminIndex')); ?>" class="list-group-item">User List</a>
            <a href="<?php echo e(route('userList')); ?>" class="list-group-item">Document</a>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>