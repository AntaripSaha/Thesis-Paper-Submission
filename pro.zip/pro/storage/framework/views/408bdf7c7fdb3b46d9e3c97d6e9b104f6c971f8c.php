<?php $__env->startSection('content'); ?>
<div class="col-xs-12">
	<div class="panel panel-default">
		<div class="panel-body">
			<h3>Abstruct Submission</h3>
			<hr>
			<div class="panel panel-default">
				<div class="panel-body">
					<form method="POST" enctype="multipart/form-data" action="<?php echo e(route('articles.store')); ?>">
						<?php echo e(csrf_field()); ?>



						<div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
							<label for="title">Paper Title *</label>
							<input type="text" class="form-control" name="title" value="<?php echo e(old('title')); ?>" placeholder="Title">
							<?php if($errors->has('title')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('title')); ?></strong>
                                </span>
                            <?php endif; ?>
						</div>

						<hr>






						<div class="form-group<?php echo e($errors->has('field') ? ' has-error' : ''); ?>">

						  <label for="field">Choose a Field:</label>

							<select name="" id="">
							  <option value="Structure Engineering">Structure Engineering</option>
  							  <option value="Geotechnical Engineering">Geotechnical Engineering</option>
  							  <option value="Water Resource Engineering">Water Resource Engineering</option>
  							  <option value="Environmental Engineering">Environmental Engineering</option>
							  <option value="------ Engineering">------ Engineering</option>
  							  <option value="Architecture">Architecture</option>
  							  <option value="Planning">Planning</option>
  							  <option value="Building Construction">Building Construction</option>
  							  <option value="Others">Others</option>  							  
							</select>

							<?php if($errors->has('field')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('field')); ?></strong>
                                </span>
                            <?php endif; ?>							

						</div>
						<hr>
						






						<div class="form-group<?php echo e($errors->has('introduction') ? ' has-error' : ''); ?>">
							<label for="introduction">Abstract/ Copy and Paste *</label>
							<textarea class="form-control comment-box" name="introduction" id="" cols="30" rows="10" placeholder="The introduction which will be seen on the Journal wall"><?php echo e(old('introduction')); ?></textarea>
							<?php if($errors->has('introduction')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('introduction')); ?></strong>
                                </span>
                            <?php endif; ?>
						</div>
						<hr>
 


						<div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
							<label for="title">Key Words*</label>
							<input type="text" class="form-control" name="title" value="<?php echo e(old('title')); ?>" placeholder="max 5">

							<?php if($errors->has('title')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('title')); ?></strong>
                                </span>
                            <?php endif; ?>
						</div>


						<div class="form-group<?php echo e($errors->has('tags') ? ' has-error' : ''); ?> form-group mt-3">
							<!-- <label for="tags">Tags</label>
							<textarea class="form-control comment-box" name="tags" id="" cols="30" rows="10" placeholder="Your tags should look like: #today #is #a #good #day"><?php echo e(old('tags')); ?></textarea> -->



							<hr>
							<!-------file upload section---->
							<label class="mr-2">Upload Abstract:</label> <!-------file upload section---->
							<input type="file" name="image" >
							<!-------file upload section---->
							<hr>




							<?php if($errors->has('tags')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('tags')); ?></strong>
                                </span>
                            <?php endif; ?>
						</div>

						
<!-- 						<div class="form-group<?php echo e($errors->has('article') ? ' has-error' : ''); ?>">
							<label for="article">Article *</label>
							<textarea class="form-control" name="article" id="" cols="30" rows="10" placeholder="Your article here"><?php echo e(old('article')); ?></textarea>
							<?php if($errors->has('article')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('article')); ?></strong>
                                </span>
                            <?php endif; ?>
						</div> -->


						<div class="form-group">
							<button class="btn btn-primary">Submit</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>