<?php $__env->startSection('content'); ?>
<div class="col-xs-8">
	<div class="panel panel-default">
		<div class="panel-body">



		<h3>
			<span class=""><a href="<?php echo e(route('articles.create')); ?>" class="btn btn-success"><i class="fa fa-clipboard" aria-hidden="true"></i> Abstract Submit</a>  &nbsp;
			<a href="<?php echo e(route('articles.create')); ?>" class="btn btn-success"><i class="fa fa-clipboard" aria-hidden="true"></i> Full Submit</a></span>  &nbsp;
			<a href="<?php echo e(route('articles.create')); ?>" class="btn btn-success"><i class="fa fa-clipboard" aria-hidden="true"></i> Camera Read Submit</a></span>
		</h3>




			<hr>


			<div class="panel-group">
				<?php if(!empty($articles)): ?>
					<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="panel panel-default">
							<div class="panel-heading">
								<h3 class="panel-title pull-left"><b><a href="<?php echo e(route('articles.show', $article->id)); ?>"><?php echo e($article->title); ?></a></b></h3>								
								<?php if(!Auth::guest()): ?>
									<?php if(Auth::user()->admin): ?>
									<div class="pull-right">
										<form method="POST" action="<?php echo e(route('articles.destroy', $article->id)); ?>">
											<a href="<?php echo e(route('articles.edit', $article->id)); ?>" class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
											<?php echo e(csrf_field()); ?>

											<?php echo e(method_field('DELETE')); ?>

											<button class="btn btn-danger btn-xs"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
										</form>
									</div>
									<?php else: ?>
										<?php $__currentLoopData = Auth::user()->articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userArticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($userArticle->id == $article->id): ?>
											<div class="pull-right">
												<form method="POST" action="<?php echo e(route('articles.destroy', $article->id)); ?>">
													<a href="<?php echo e(route('articles.edit', $article->id)); ?>" class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
													<?php echo e(csrf_field()); ?>

													<?php echo e(method_field('DELETE')); ?>

													<button class="btn btn-danger btn-xs"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
												</form>
											</div>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								<?php endif; ?>
								<div class="clearfix"></div>
							</div>
							<div class="panel-body">
								<p><?php echo e($article->introduction); ?></p>
								<a href="<?php echo e(route('articles.show', $article->id)); ?>" class="btn btn-link pull-right">Read more</a>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>


 <?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('layouts.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>