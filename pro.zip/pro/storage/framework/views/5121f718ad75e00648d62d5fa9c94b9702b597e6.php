<?php $__env->startSection('content'); ?>

<style type="text/css">
	
.design{
	padding-top: 15%;
}	
</style>

<!-- 	
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

 -->

	

<div class="col-xs-8">
  <div class="panel panel-default">
    <div class="panel-body">
      <h3>Documents</h3>
    </div>
  </div>


<div class="design">
<table class="table">
  <tr>
      <th scope="col">User Id</th>
      <th scope="col">Id</th>
      <th scope="col">Category</th>
      <th scope="col">Title</th>
      <th scope="col">Field</th>
      <th scope="col">Introduction</th>
      <th scope="col">Key Word</th>
      <th scope="col">Pdf File</th>
      <th scope="col">Docx File</th>      
      <!--<th scope="col">DELETE</th>      -->

   </tr>
  <?php $__currentLoopData = $userlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>



      <th scope="row"><?php echo e($user['user_id']); ?></th>
      <td><?php echo e($user['id']); ?></td>
      <td><?php echo e($user['category']); ?></td>
      <td><?php echo e($user['title']); ?></td>
      <td><?php echo e($user['field']); ?></td>
      <td><?php echo e($user['introduction']); ?></td>
      <td><?php echo e($user['keyword']); ?></td>
      <td><a href="<?php echo e(asset('uploads/employee/'.$user->image)); ?>"><?php echo e($user['image']); ?></td> 
      <td><a href="<?php echo e(asset('uploads/employee/'.$user->image2)); ?>"><?php echo e($user['image2']); ?></td> 


      <!--<td><a href="/delete/<?php echo e($user->id); ?>" class="btn btn-danger">Delete</a></td> -->

      <!-- <td><a href=<?php echo e("delete/".$user['id']); ?> class="btn btn-danger">Delete</a></td> -->

  </tr>                     
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>




</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<div class="col-xs-4">
  <div class="row">
    <div class="panel-group">
      <div class="panel panel-default">
        <div class="panel-heading">
          <h3 class="panel-title">Admin panel</h3>
        </div>
        <div class="panel-body">
          <ul class="list-group">
            <a href="<?php echo e(route('adminIndex')); ?>" class="list-group-item">User List</a>
            <a href="<?php echo e(route('userList')); ?>" class="list-group-item">Document</a>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>