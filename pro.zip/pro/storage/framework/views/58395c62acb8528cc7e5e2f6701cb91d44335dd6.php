<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title>Journal</title>
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
	<script src="<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/app.js')); ?>"></script>
	<script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="navbar navbar-default navbar-fixed-top">
				<div class="container">
					<div class="navbar-header">
						<a href="<?php echo e(route('home')); ?>" class="navbar-brand"></a>
						<button class="navbar-toggle" data-toggle="collapse" data-target="#menu">
							<span class="sr-only">Menu</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					</div>
					<div class="collapse navbar-collapse" id="menu">
						<?php if(Auth::guest()): ?>
<!-- 						<ul class="nav navbar-nav">
							<li><a href="<?php echo e(route('articles.index')); ?>">Wall</a></li>
							<li><a href="<?php echo e(route('feedback.index')); ?>">Feedback</a></li>
						</ul> -->
						<ul class="nav navbar-nav navbar-right">
							<li><a href="<?php echo e(route('register')); ?>"><h4><b>Sign up</b><h4></a></li>
							<li><a href="<?php echo e(route('login')); ?>"><h4><b>Sign in</b><h4></a></li>
						</ul>
						<?php else: ?>
<!-- 						<ul class="nav navbar-nav">
							<li><a href="<?php echo e(route('articles.index')); ?>">Wall</a></li>
							<li><a href="<?php echo e(route('feedback.index')); ?>">Feedback</a></li>
							<li><a href="<?php echo e(route('profile.index')); ?>">Profile</a></li>
						</ul> -->
						<ul class="nav navbar-nav navbar-right">
							<li>
								<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><h4><b>Log Out</b><h4></a>
								<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
	                                <?php echo e(csrf_field()); ?>

	                            </form>
							</li>
						</ul>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Ident from navbar, because navbar-fixed-top comes on top of the main container -->
	<div class="navbar-ident"></div>
	<!-- Ident from navbar, because navbar-fixed-top comes on top of the main container -->
	<div class="container">
		<div class="row">
			<?php echo $__env->yieldContent('content'); ?>
			<!-- Search by tag and follow us block's -->
			<?php echo $__env->yieldContent('sidebar'); ?>
		</div>
	</div>
</body>
</html>