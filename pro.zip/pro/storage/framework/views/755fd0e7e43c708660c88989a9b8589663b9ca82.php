<?php $__env->startSection('content'); ?>



<header>
    <style type="text/css">
        body{
    
        background-image: url('/ICPACE-21-web-banner-scaled-1-1.jpg');
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: 100% 40%;


    }
    .resize{
        padding-top: 300px;

    }


    </style>
    
</header>


<div class="col-xs-8 resize">
    <div class="panel panel-default">
        <div class="panel-body">
            <h3>Sign in</h3>
            <hr>
            <div class="panel panel-default">
                <div class="panel-body">
                    <form role="form" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                    <label for="email">E-mail</label>
                                    <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="E-mail" required autofocus>
                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                    <label for="password">Password</label>
                                    <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>
                                     <?php if(!$errors->has('password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-6">
                                <div class="form-group">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                        </label>
                                    </div>
                                </div>    
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group">
                                    <button class="btn btn-primary">Sign in</button>
                                    <a href="<?php echo e(route('password.request')); ?>" class="btn btn-link">Forgot Your Password?</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('layouts.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>