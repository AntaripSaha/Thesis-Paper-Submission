<?php $__env->startSection('content'); ?>
<div class="col-xs-12">
	<div class="panel panel-default">
		<div class="panel-body">
			<!-- <h3><?php echo e($article->title); ?></h3> -->
			<h2>Your file has been Submitted Succesfully.
								Thanks for visiting this site. 

							</h2>
<!-- 			<hr>
			<div class="panel-group">
				<div class="panel panel-default">
					<div class="panel-body">
						<p><?php echo e($article->article); ?></p>


						<div>
							
							
						</div>



						

						<div>
							<h5><a href="<?php echo e(asset('uploads/employee/'.$article->image)); ?>">View PDF</a></h5> 
						
			 			
						</div>
					

						

						<hr>
						<a href="<?php echo e(url('/')); ?>" class="btn btn-link"><i class="fa fa-undo" aria-hidden="true"></i> Back to the Journal wall</a>





						<div class="pull-right">
							<a href="<?php echo e(route('articles.like', [$article->id, 1])); ?>" class="btn btn-success"><i class="fa fa-thumbs-up" aria-hidden="true"></i></a>
							<i><?php echo e($article->rating); ?></i>
							<a href="<?php echo e(route('articles.like', [$article->id, 0])); ?>" class="btn btn-danger"><i class="fa fa-thumbs-down" aria-hidden="true"></i></a>
						</div>
					</div>
				</div>

				<h3>Add comment</h3>
											
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="row">
							<div class="col-xs-1">
								<img src="http://placehold.it/48x48" alt="">
							</div>
							<div class="col-xs-11">
								<?php if(Auth::guest()): ?>
									<div class="form-group">
										<textarea disabled class="form-control comment-box" cols="30" rows="10" placeholder="Sign in to comment!"></textarea>
									</div>
									<div class="form-group">
										<input disabled type="submit" class="btn btn-primary" value="Add">
									</div>
								<?php else: ?>
									<form method="POST" action="<?php echo e(route('articles.comment', $article->id)); ?>">
										<?php echo e(csrf_field()); ?>

										<div class="form-group<?php echo e($errors->has('comment') ? ' has-error' : ''); ?>">
											<textarea class="form-control comment-box" cols="30" rows="10" name="comment" placeholder="Enter your text here..."><?php echo e(old('comment')); ?></textarea>
											<?php if($errors->has('comment')): ?>
				                                <span class="help-block">
				                                    <strong><?php echo e($errors->first('comment')); ?></strong>
				                                </span>
				                            <?php endif; ?>
										</div>
										<div class="form-group">
											<input type="submit" class="btn btn-primary" value="Add">
										</div>
									</form>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
					
				<h3>Comments: <i><?php echo e($count); ?></i></h3>

				<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($article->id == $comment->user_id): ?>
				<div class="panel panel-success">
					<div class="panel-heading">
						<b><?php echo e($comment->user->username); ?></b><i class="pull-right"><?php echo e($comment->created_at); ?></i>
					</div>
				<?php else: ?>
				<div class="panel panel-default">
					<div class="panel-heading">
						<b><?php echo e($comment->user->username); ?></b><i class="pull-right"><?php echo e($comment->created_at); ?></i>
					</div>
				<?php endif; ?>
					<div class="panel-body">
						<div class="row">
							<div class="col-xs-1">
								<img src="http://placehold.it/48x48" alt="">
							</div>
							<div class="col-xs-11">
								<p>
									<?php echo e($comment->comment); ?>	
								</p>
								<hr>
								<button id="reply-<?php echo e($comment->id); ?>" onClick="reply(<?php echo e($comment->id); ?>)" class="btn btn-link" style="padding-left: 0;">Reply</button>
								
								<?php if(!Auth::guest() && Auth::user()->admin): ?>
								<form method="POST" action="<?php echo e(route('articles.comment.destroy', [$article->id, $comment->id])); ?>">
									<?php echo e(csrf_field()); ?>

									<?php echo e(method_field('DELETE')); ?>

									<button class="btn btn-danger btn-xs"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
								</form>
								<?php endif; ?>

								<div class="clearfix" style="margin-bottom: 15px;"></div>
								<form id="answer-<?php echo e($comment->id); ?>" method="POST" action="<?php echo e(route('articles.comment.subcomment', [$article->id, $comment->id])); ?>" hidden >
									<?php echo e(csrf_field()); ?>

									<div class="form-group">
										<textarea class="form-control comment-box" cols="30" rows="10" name="comment" placeholder="Enter your text here..."></textarea>
									</div>
									<div class="form-group">
										<button class="btn btn-success">Send</button>
									</div>
								</form>
								<div class="panel-group">
									<?php $__currentLoopData = $subcomments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcomment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($subcomment->comment_id == $comment->id): ?>
									Sub comment -->
									
									<?php if($article->id == $subcomment->user_id): ?>
									<div class="panel panel-success">
										<div class="panel-heading">
											<b><?php echo e($subcomment->user->username); ?></b><i class="pull-right"><?php echo e($subcomment->created_at); ?></i>
										</div>
									<?php else: ?>
									<div class="panel panel-default">
										<div class="panel-heading">
											<b><?php echo e($subcomment->user->username); ?></b><i class="pull-right"><?php echo e($subcomment->created_at); ?></i>
										</div>
									<?php endif; ?>
										<div class="panel-body">
											<div class="row">
												<div class="col-xs-1">
													<img src="http://placehold.it/48x48" alt="">
												</div>
												<div class="col-xs-11">
													<p>
														<?php echo e($subcomment->comment); ?>	
													</p>
													<hr>
													<?php if(!Auth::guest() && Auth::user()->admin): ?>
													<form method="POST" action="<?php echo e(route('articles.comment.subcomment.destroy', [$article->id, $subcomment->id])); ?>">
														<?php echo e(csrf_field()); ?>

														<?php echo e(method_field('DELETE')); ?>

														<button class="btn btn-danger btn-xs"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
													</form>
													<?php endif; ?>
												</div>
											</div>
										</div>
									</div>
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div> -->
</div>
<script>
	function reply(id) {
		console.log(id);
		$("#reply-"+id).hide();
		$("#answer-"+id).fadeIn('slow');
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>