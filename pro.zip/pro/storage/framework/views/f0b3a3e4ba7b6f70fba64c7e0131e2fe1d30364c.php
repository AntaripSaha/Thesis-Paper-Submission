<?php $__env->startSection('content'); ?>
<div class="col-xs-12">
	<div class="panel panel-default">
		<div class="panel-body">
			<h3>Article editing</h3>
			<hr>
			<div class="panel panel-default">
				<div class="panel-body">
					<form method="POST" action="<?php echo e(route('articles.update', $article->id)); ?>">
						<?php echo e(csrf_field()); ?>

						<?php echo e(method_field('PUT')); ?>

						<div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
							<label for="title">Title *</label>
							<input type="text" class="form-control" name="title" value="<?php echo e(old('title', $article->title)); ?>" placeholder="Title">
							<?php if($errors->has('title')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('title')); ?></strong>
                                </span>
                            <?php endif; ?>
						</div>
						<div class="form-group<?php echo e($errors->has('introduction') ? ' has-error' : ''); ?>">
							<label for="introduction">Introduction *</label>
							<textarea class="form-control comment-box" name="introduction" id="" cols="30" rows="10" placeholder="The introduction which will be seen on the Journal wall"><?php echo e(old('introduction', $article->introduction)); ?></textarea>
							<?php if($errors->has('introduction')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('introduction')); ?></strong>
                                </span>
                            <?php endif; ?>
						</div>
						<div class="form-group<?php echo e($errors->has('tags') ? ' has-error' : ''); ?>">
							<label for="tags">Tags</label>
							<textarea class="form-control comment-box" name="tags" id="" cols="30" rows="10" placeholder="Your tags should look like: #today #is #a #good #day"><?php echo e(old('tags', $article->tags)); ?></textarea>
							<?php if($errors->has('tags')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('tags')); ?></strong>
                                </span>
                            <?php endif; ?>
						</div>
						<div class="form-group<?php echo e($errors->has('article') ? ' has-error' : ''); ?>">
							<label for="article">Article *</label>
							<textarea class="form-control" name="article" id="" cols="30" rows="10" placeholder="Your article here"><?php echo e(old('article', $article->article)); ?></textarea>
							<?php if($errors->has('article')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('article')); ?></strong>
                                </span>
                            <?php endif; ?>
						</div>
						<div class="form-group">
							<button class="btn btn-success">Save changes</button>
							<a href="<?php echo e(route('articles.index')); ?>" class="btn btn-danger">Cancel, back to the wall</a>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>