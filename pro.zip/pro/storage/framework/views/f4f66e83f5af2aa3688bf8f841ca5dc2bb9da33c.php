<?php $__env->startSection('content'); ?>


<header>
    <style type="text/css">
        body{
    
        background-image: url('/ICPACE-21-web-banner-scaled-1-1.jpg');
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: 100% 40%;


    }
     .resize{
        padding-top: 300px;

    }

    </style>
    
</header>


<div class="col-xs-8 resize">
    <div class="panel panel-default">
        <div class="panel-body">
            <h3>Sign up</h3>
            <hr>
            <div class="panel panel-default">
                <div class="panel-body">
                    <form role="form" method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo e(csrf_field()); ?>




   





                        <div class="row">
                            <div class="col-xs-6">
                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                    <label for="name">First Name</label>
                                    <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" placeholder="First Name" required>
                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-xs-6">
                                <div class="form-group<?php echo e($errors->has('surname') ? ' has-error' : ''); ?>">
                                    <label for="surname">Last Name</label>
                                    <input type="text" class="form-control" name="surname" value="<?php echo e(old('surname')); ?>" placeholder="Last Name" required>
                                    <?php if($errors->has('surname')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('surname')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>





                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group<?php echo e($errors->has('birthdate') ? ' has-error' : ''); ?>">
                                    <label for="birthdate">Affiliation</label>
                                    <input type="text" class="form-control" name="birthdate" value="<?php echo e(old('birthdate')); ?>" placeholder="Affiliation">
                                    <?php if($errors->has('birthdate')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('birthdate')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
















                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                    <label for="email">E-mail</label>
                                    <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Remember this E-mail for further login" required>
                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>






                        

                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                                    <label for="username">Username</label>
                                    <input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" placeholder="Username" required autofocus>
                                    <?php if($errors->has('username')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('username')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>                     




                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                    <label for="password">Password</label>
                                    <input type="password" class="form-control" name="password" placeholder="Remember this Password for further login" required>
                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>



                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group">
                                    <button class="btn btn-primary">Sign up</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('layouts.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>